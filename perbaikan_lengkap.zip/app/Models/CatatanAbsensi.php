<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CatatanAbsensi extends Model
{
    protected $table = 'catatan_absensi';

    protected $fillable = [
        'siswa_id',
        'jenis',
        'tanggal',
        'waktu_mulai',
        'waktu_selesai',
        'kegiatan',
        'keterangan',
        'dibuat_oleh',
        'status_tindak_lanjut',
        'catatan_tindak_lanjut',
        'ditindaklanjuti_oleh',
        'ditindaklanjuti_at',
    ];

    protected function casts(): array
    {
        return [
            'tanggal' => 'date',
            'ditindaklanjuti_at' => 'datetime',
        ];
    }

    public function siswa(): BelongsTo
    {
        return $this->belongsTo(Siswa::class);
    }

    public function pembuat(): BelongsTo
    {
        return $this->belongsTo(User::class, 'dibuat_oleh');
    }

    public function penindakLanjut(): BelongsTo
    {
        return $this->belongsTo(User::class, 'ditindaklanjuti_oleh');
    }

    public function labelTindakLanjut(): string
    {
        return match ($this->status_tindak_lanjut) {
            'sudah_dihubungi' => 'Sudah dihubungi',
            'perlu_tindak_lanjut' => 'Perlu tindak lanjut',
            'selesai' => 'Selesai',
            default => 'Belum',
        };
    }
}
