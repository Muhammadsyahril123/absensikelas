<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Dashboard Guru Piket</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
          rel="stylesheet">
</head>

<body class="bg-light">

<nav class="navbar navbar-dark bg-primary">
    <div class="container">
        <span class="navbar-brand fw-bold">Absensi Kelas</span>

        <form action="{{ route('logout') }}" method="POST">
            @csrf
            <button class="btn btn-light btn-sm">Logout</button>
        </form>
    </div>
</nav>

<div class="container py-5">

    <div class="bg-white p-4 rounded-4 shadow-sm">
        <h3 class="fw-bold">Dashboard Guru Piket</h3>

        <p class="text-secondary">
            Selamat datang, {{ auth()->user()->name }}!
        </p>

        <div class="alert alert-primary mb-0">
            Nantinya, guru piket dapat mencatat dispensasi,
            sakit mendadak, dan siswa yang pulang lebih awal.
        </div>
      <a href="{{ route('dispensasi.piket') }}" class="btn btn-primary">
    Kelola Dispensasi
      </a>
      <a
    href="{{ route('guru-piket.pemeriksaan') }}"
    class="btn btn-primary">
    Periksa Izin, Sakit, dan Keterlambatan
      </a>
    </div>

</div>

</body>
</html>